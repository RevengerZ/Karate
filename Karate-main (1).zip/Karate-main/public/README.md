Place static assets (images, robots.txt, etc.) here. Files in `public/` are served from the site root.

Example: `public/hanshi.jpg` will be available at `/hanshi.jpg`.
